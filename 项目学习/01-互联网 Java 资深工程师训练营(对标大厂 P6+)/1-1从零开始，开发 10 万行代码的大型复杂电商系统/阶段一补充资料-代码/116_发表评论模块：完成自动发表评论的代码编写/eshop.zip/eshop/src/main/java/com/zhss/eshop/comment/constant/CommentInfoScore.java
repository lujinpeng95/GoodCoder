package com.zhss.eshop.comment.constant;

/**
 * 评论分数的常量类
 * @author zhonghuashishan
 *
 */
public class CommentInfoScore {

	public static final Integer ONE = 1;
	public static final Integer TWO = 1;
	public static final Integer THREE = 1;
	public static final Integer FOUR = 1;
	public static final Integer FIVE = 1;
	
}
