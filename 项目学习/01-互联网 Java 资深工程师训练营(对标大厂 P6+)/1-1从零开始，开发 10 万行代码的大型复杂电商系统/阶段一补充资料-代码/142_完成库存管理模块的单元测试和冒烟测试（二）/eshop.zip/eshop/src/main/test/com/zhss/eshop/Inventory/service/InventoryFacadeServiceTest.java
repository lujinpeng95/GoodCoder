package com.zhss.eshop.Inventory.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.zhss.eshop.Inventory.dao.GoodsStockDAO;
import com.zhss.eshop.Inventory.domain.GoodsStockDO;
import com.zhss.eshop.common.util.DateProvider;
import com.zhss.eshop.wms.domain.PurchaseInputOrderDTO;
import com.zhss.eshop.wms.domain.PurchaseInputOrderItemDTO;
import com.zhss.eshop.wms.domain.PurchaseInputOrderPutOnItemDTO;
import com.zhss.eshop.wms.domain.ReturnGoodsInputOrderDTO;
import com.zhss.eshop.wms.domain.ReturnGoodsInputOrderItemDTO;
import com.zhss.eshop.wms.domain.ReturnGoodsInputOrderPutOnItemDTO;

/**
 * 库存中心service组件的单元测试类
 * @author zhonghuashishan
 *
 */
@RunWith(SpringRunner.class) 
@SpringBootTest
public class InventoryFacadeServiceTest {
	
	/**
	 * 库存中心service组件
	 */
	@Autowired
	private InventoryService inventoryService;
	/**
	 * 日期辅助组件
	 */
	@Autowired
	private DateProvider dateProvider;
	/**
	 * 商品库存管理DAO组件
	 */
	@Autowired
	private GoodsStockDAO goodsStockDAO;
	
	/**
	 * 测试通知库存中心，“采购入库完成”事件发生了
	 * @throws Exception
	 */
	@Test
	public void testInformPurchaseInputFinished() throws Exception {
		// 准备商品sku id集合
		Long[] goodsSkuIds = new Long[]{1L, 2L};
		// 准备商品sku对应的销售库存map，将每个商品sku id对应的销售库存放在map中
		Map<Long, Long> oldSaleStockQuantityMap = new HashMap<Long, Long>();
		for(Long goodsSkuId : goodsSkuIds) {
			oldSaleStockQuantityMap.put(goodsSkuId, getSaleStockQuantity(goodsSkuId));
		}
		// 准备采购数量
		Long purchaseQuantity = 1000L;
		
		// 构造一个采购入库单，有两个条目，其goodsSkuId分别为1和2，同时采购数量为1000
		PurchaseInputOrderDTO purchaseInputOrder = createPurchaseInputOrder(
				purchaseQuantity, goodsSkuIds);    
		inventoryService.informPurchaseInputFinished(purchaseInputOrder);
		
		// 然后来执行断言
		for(Long goodsSkuId : goodsSkuIds) { 
			assertEquals((long)oldSaleStockQuantityMap.get(goodsSkuId) + purchaseQuantity, 
					(long)getSaleStockQuantity(goodsSkuId));  
		}
	}
	
	/**
	 * 测试通知库存中心，“完成退货入库”事件发生了
	 * @throws Exception
	 */
	@Test
	public void testInformReturnGoodsInputFinished() throws Exception {
		// 准备两个库存数据，分别是goodsSkuId为3和4
		// 这两份数据的销售库存为50，已销售库存为100
		Long[] goodsSkuIds = new Long[] {3L, 4L};
		Long oldSaleStockQuantity = 50L;
		Long oldSaledStockQuantity = 100L;
		Long purchaseQuantity = 3L;
		
		for(Long goodsSkuId : goodsSkuIds) {
			prepareDataForReturnGoodsInputTest(goodsSkuId, 
					oldSaleStockQuantity, oldSaledStockQuantity); 
		}
		
		// 构造一个退货入库单，有两个商品条目，goodsSkuId分别为3和4，其购买数量都是3
		ReturnGoodsInputOrderDTO returnGoodsInputOrder = createReturnGoodsInputOrder(
				purchaseQuantity, goodsSkuIds);
		inventoryService.informReturnGoodsInputFinished(returnGoodsInputOrder);
		
		// 执行断言
		for(Long goodsSkuId : goodsSkuIds) {
			assertEquals((long)oldSaleStockQuantity + purchaseQuantity, 
					(long)getSaleStockQuantity(goodsSkuId));   
			assertEquals((long)oldSaledStockQuantity - purchaseQuantity, 
					(long)getSaledStockQuantity(goodsSkuId));  
		}
	}
	
	/**
	 * 查询商品sku的销售库存
	 * @throws Exception
	 */
	private Long getSaleStockQuantity(Long goodsSkuId) throws Exception {
		GoodsStockDO stock = goodsStockDAO.getGoodsStockBySkuId(goodsSkuId); 
		if(stock == null) {
			return 0L;
		} else {
			return stock.getSaleStockQuantity();
		}
	}
	
	/**
	 * 查询商品sku的已销售库存
	 * @param goodsSkuId 商品sku id
	 * @return
	 * @throws Exception
	 */
	private Long getSaledStockQuantity(Long goodsSkuId) throws Exception {
		GoodsStockDO stock = goodsStockDAO.getGoodsStockBySkuId(goodsSkuId); 
		if(stock == null) {
			return 0L;
		} else {
			return stock.getSaledStockQuantity();
		}
	}
	
	/**
	 * 
	 * 为退货入库的测试准备数据
	 * @throws Exception
	 */
	private void prepareDataForReturnGoodsInputTest(Long goodsSkuId, 
			Long saleStockQuantity, Long saledStockQuantity) throws Exception {
		GoodsStockDO stock = goodsStockDAO.getGoodsStockBySkuId(goodsSkuId);
		
		if(stock == null) {
			stock = new GoodsStockDO();
			stock.setGoodsSkuId(goodsSkuId); 
			stock.setSaleStockQuantity(saleStockQuantity); 
			stock.setLockedStockQuantity(0L);
			stock.setSaledStockQuantity(saledStockQuantity); 
			stock.setStockStatus(1); 
			stock.setGmtCreate(dateProvider.getCurrentTime()); 
			stock.setGmtModified(dateProvider.getCurrentTime()); 
			
			goodsStockDAO.saveGoodsStock(stock);
		} else {
			stock.setSaleStockQuantity(saleStockQuantity); 
			stock.setLockedStockQuantity(0L);
			stock.setSaledStockQuantity(saledStockQuantity); 
			stock.setStockStatus(1); 
			
			goodsStockDAO.updateGoodsStock(stock);
		}
	}
	
	/**
	 * 创建采购入库单
	 * @return 采购入库单
	 * @throws Exception
	 */
	private PurchaseInputOrderDTO createPurchaseInputOrder(Long count, Long...goodsSkuIds) throws Exception {
		PurchaseInputOrderDTO order = new PurchaseInputOrderDTO();
		
		order.setId(1L); 
		order.setSupplierId(1L); 
		order.setExpectArrivalTime(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		order.setArrivalTime(dateProvider.parseDatetime("2018-01-10 10:05:00"));
		order.setPurchaseContactor("张三");  
		order.setPurchaseContactPhoneNumber("18910106578");  
		order.setPurchaseContactEmail("zhangsan@sina.com");  
		order.setPurchaseInputOrderComment("测试采购入库单");
		order.setPurchaser("李四");  
		order.setPurcahseInputOrderStatus(5); 
		order.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		order.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		
		List<PurchaseInputOrderItemDTO> items = new ArrayList<PurchaseInputOrderItemDTO>();
		for(int i = 0; i < goodsSkuIds.length; i++) {   
			items.add(createPurchaseInputItem((long)i, goodsSkuIds[i], 1L, count)); 
		}
		order.setPurchaseInputOrderItemDTOs(items);

		List<PurchaseInputOrderPutOnItemDTO> putOnItems = 
				new ArrayList<PurchaseInputOrderPutOnItemDTO>();
		for(int i = 0; i < goodsSkuIds.length; i++) {
			putOnItems.add(createPurchaseInputOrderPutOnItem((long)i, (long)i));   
		}
		order.setPurchaseInputOrderPutOnItemDTOs(putOnItems); 
		
		return order;
	}
	
	/**
	 * 创建采购入库单条目
	 * @return 采购入库单条目
	 * @throws Exception
	 */
	private PurchaseInputOrderItemDTO createPurchaseInputItem(
			Long itemId, Long goodsSkuId, Long orderId, Long count) throws Exception {
		PurchaseInputOrderItemDTO item = new PurchaseInputOrderItemDTO();
		item.setId(itemId);  
		item.setPurchaseInputOrderId(orderId); 
		item.setGoodsSkuId(goodsSkuId); 
		item.setPurchaseCount(count); 
		item.setQualifiedCount(count); 
		item.setArrivalCount(count);  
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		return item;
	}
	
	/**
	 * 创建采购入库单上架条目
	 * @return 采购入库单上架条目
	 * @throws Exception
	 */
	private PurchaseInputOrderPutOnItemDTO createPurchaseInputOrderPutOnItem(
			Long putOnItemId, Long itemId) throws Exception {
		PurchaseInputOrderPutOnItemDTO item = new PurchaseInputOrderPutOnItemDTO();
		item.setId(putOnItemId);
		item.setPurchaseInputOrderItemId(itemId); 
		item.setGoodsAllocationId(1L); 
		item.setPutOnShelvesCount(1000L); 
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		return item;
	}
	
	/**
	 * 创建退货入库单
	 * @return 退货入库单
	 * @throws Exception
	 */
	private ReturnGoodsInputOrderDTO createReturnGoodsInputOrder(
			Long purchaseQuantity, Long...goodsSkuIds) throws Exception {
		ReturnGoodsInputOrderDTO returnGoodsInputOrder = new ReturnGoodsInputOrderDTO();
		
		returnGoodsInputOrder.setId(1L); 
		returnGoodsInputOrder.setUserAccountId(1L); 
		returnGoodsInputOrder.setOrderId(1L); 
		returnGoodsInputOrder.setOrderNo("test"); 
		returnGoodsInputOrder.setReturnGoodsInputOrderStatus(3); 
		returnGoodsInputOrder.setConsignee("张三");
		returnGoodsInputOrder.setDeliveryAddress("测试地址"); 
		returnGoodsInputOrder.setConsigneeCellPhoneNumber("18910106578");
		returnGoodsInputOrder.setFreight(45.90);
		returnGoodsInputOrder.setPayType(1); 
		returnGoodsInputOrder.setTotalAmount(999.00); 
		returnGoodsInputOrder.setDiscountAmount(50.40);
		returnGoodsInputOrder.setCouponAmount(35.00); 
		returnGoodsInputOrder.setPayableAmount(899.30); 
		returnGoodsInputOrder.setInvoiceTitle("测试发票抬头"); 
		returnGoodsInputOrder.setTaxpayerId("测试纳税人识别号");
		returnGoodsInputOrder.setOrderComment("测试订单");
		returnGoodsInputOrder.setReturnGoodsReason("测试退货原因");
		returnGoodsInputOrder.setReturnGoodsComment("测试退货备注"); 
		returnGoodsInputOrder.setArrivalTime(dateProvider.parseDatetime("2018-01-10 10:00:00")); 
		returnGoodsInputOrder.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		returnGoodsInputOrder.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		
		List<ReturnGoodsInputOrderItemDTO> items = new ArrayList<ReturnGoodsInputOrderItemDTO>();
		for(Long goodsSkuId : goodsSkuIds) {
			items.add(createReturnGoodsInputOrderItem(1L, goodsSkuId, purchaseQuantity)); 
		}
		returnGoodsInputOrder.setReturnGoodsInputOrderItemDTOs(items); 
		
		List<ReturnGoodsInputOrderPutOnItemDTO> putOnItems = 
				new ArrayList<ReturnGoodsInputOrderPutOnItemDTO>();
		for(int i = 0; i < goodsSkuIds.length; i++) {
			putOnItems.add(createReturnGoodsInputOrderPutOnItem((long)i, (long)i)); 
		}
		returnGoodsInputOrder.setReturnGoodsInputOrderPutOnItemDTO(putOnItems); 
		
		return returnGoodsInputOrder;
	}
	
	/**
	 * 创建退货入库单条目
	 * @param returnGoodsInputOrderId 退货入库单id
	 * @return 退货入库单条目
	 * @throws Exception
	 */
	private ReturnGoodsInputOrderItemDTO createReturnGoodsInputOrderItem(
			Long returnGoodsInputOrderId, 
			Long goodsSkuId,
			Long purchaseQuantity) throws Exception {
		ReturnGoodsInputOrderItemDTO item = new ReturnGoodsInputOrderItemDTO();
		
		item.setReturnGoodsInputOrderId(returnGoodsInputOrderId); 
		item.setGoodsSkuId(goodsSkuId); 
		item.setGoodsSkuCode("测试编号"); 
		item.setGoodsName("测试商品"); 
		item.setSaleProperties("测试销售属性"); 
		item.setGoodsGrossWeight(59.30);
		item.setPurchaseQuantity(purchaseQuantity); 
		item.setPurchasePrice(39.30); 
		item.setPromotionActivityId(1L); 
		item.setGoodsLength(49.00); 
		item.setGoodsWidth(29.50); 
		item.setGoodsHeight(68.90); 
		item.setQualifiedCount(purchaseQuantity); 
		item.setArrivalCount(purchaseQuantity); 
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		
		return item;
	}
	
	/**
	 * 创建退货入库单上架条目
	 * @return 采购入库单上架条目
	 * @throws Exception
	 */
	private ReturnGoodsInputOrderPutOnItemDTO createReturnGoodsInputOrderPutOnItem(
			Long putOnItemId, Long itemId) throws Exception {
		ReturnGoodsInputOrderPutOnItemDTO item = new ReturnGoodsInputOrderPutOnItemDTO();
		item.setId(putOnItemId);
		item.setReturnGoodsInputOrderItemId(itemId); 
		item.setGoodsAllocationId(1L); 
		item.setPutOnShelvesCount(1000L); 
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		return item;
	}
	
}
