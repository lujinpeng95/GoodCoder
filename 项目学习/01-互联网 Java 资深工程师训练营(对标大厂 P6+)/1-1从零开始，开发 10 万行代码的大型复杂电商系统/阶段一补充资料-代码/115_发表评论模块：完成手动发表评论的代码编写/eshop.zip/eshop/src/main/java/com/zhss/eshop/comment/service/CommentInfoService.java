package com.zhss.eshop.comment.service;

import com.zhss.eshop.comment.domain.CommentInfoDTO;

/**
 * 评论信息管理模块的service组件接口
 * @author zhonghuashishan
 *
 */
public interface CommentInfoService {

	/**
	 * 新增评论信息
	 * @param commentInfoDTO 评论信息DTO对象
	 */
	Boolean saveCommentInfo(CommentInfoDTO commentInfoDTO);
	
}
