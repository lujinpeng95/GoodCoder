package com.zhss.eshop.Inventory.service;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.zhss.eshop.common.util.DateProvider;
import com.zhss.eshop.wms.domain.PurchaseInputOrderDTO;
import com.zhss.eshop.wms.domain.PurchaseInputOrderItemDTO;
import com.zhss.eshop.wms.domain.PurchaseInputOrderPutOnItemDTO;
import com.zhss.eshop.wms.domain.ReturnGoodsInputOrderDTO;
import com.zhss.eshop.wms.domain.ReturnGoodsInputOrderItemDTO;
import com.zhss.eshop.wms.domain.ReturnGoodsInputOrderPutOnItemDTO;

/**
 * 库存中心service组件的单元测试类
 * @author zhonghuashishan
 *
 */
@RunWith(SpringRunner.class) 
@SpringBootTest
public class InventoryFacadeServiceTest {
	
	/**
	 * 库存中心service组件
	 */
	@Autowired
	private InventoryService inventoryService;
	/**
	 * 日期辅助组件
	 */
	@Autowired
	private DateProvider dateProvider;
	
	/**
	 * 测试通知库存中心，“采购入库完成”事件发生了
	 * @throws Exception
	 */
	@Test
	public void testInformPurchaseInputFinished() throws Exception {
		PurchaseInputOrderDTO purchaseInputOrder = createPurchaseInputOrder();
		inventoryService.informPurchaseInputFinished(purchaseInputOrder);
	}
	
	/**
	 * 测试通知库存中心，“完成退货入库”事件发生了
	 * @throws Exception
	 */
	@Test
	public void testInformReturnGoodsInputFinished() throws Exception {
		ReturnGoodsInputOrderDTO returnGoodsInputOrder = createReturnGoodsInputOrder();
		inventoryService.informReturnGoodsInputFinished(returnGoodsInputOrder);
	}
	
	/**
	 * 创建采购入库单
	 * @return 采购入库单
	 * @throws Exception
	 */
	private PurchaseInputOrderDTO createPurchaseInputOrder() throws Exception {
		PurchaseInputOrderDTO order = new PurchaseInputOrderDTO();
		
		order.setId(1L); 
		order.setSupplierId(1L); 
		order.setExpectArrivalTime(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		order.setArrivalTime(dateProvider.parseDatetime("2018-01-10 10:05:00"));
		order.setPurchaseContactor("张三");  
		order.setPurchaseContactPhoneNumber("18910106578");  
		order.setPurchaseContactEmail("zhangsan@sina.com");  
		order.setPurchaseInputOrderComment("测试采购入库单");
		order.setPurchaser("李四");  
		order.setPurcahseInputOrderStatus(5); 
		order.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		order.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		
		List<PurchaseInputOrderItemDTO> items = new ArrayList<PurchaseInputOrderItemDTO>();
		items.add(createPurchaseInputItem(1L, 1L, 1L)); 
		items.add(createPurchaseInputItem(2L, 2L, 1L)); 
		order.setPurchaseInputOrderItemDTOs(items);

		List<PurchaseInputOrderPutOnItemDTO> putOnItems = 
				new ArrayList<PurchaseInputOrderPutOnItemDTO>();
		putOnItems.add(createPurchaseInputOrderPutOnItem(1L, 1L)); 
		putOnItems.add(createPurchaseInputOrderPutOnItem(2L, 2L)); 
		order.setPurchaseInputOrderPutOnItemDTOs(putOnItems); 
		
		return order;
	}
	
	/**
	 * 创建采购入库单条目
	 * @return 采购入库单条目
	 * @throws Exception
	 */
	private PurchaseInputOrderItemDTO createPurchaseInputItem(
			Long itemId, Long goodsSkuId, Long orderId) throws Exception {
		PurchaseInputOrderItemDTO item = new PurchaseInputOrderItemDTO();
		item.setId(itemId);  
		item.setPurchaseInputOrderId(orderId); 
		item.setGoodsSkuId(goodsSkuId); 
		item.setPurchaseCount(1000L); 
		item.setQualifiedCount(1000L); 
		item.setArrivalCount(1000L); 
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		return item;
	}
	
	/**
	 * 创建采购入库单上架条目
	 * @return 采购入库单上架条目
	 * @throws Exception
	 */
	private PurchaseInputOrderPutOnItemDTO createPurchaseInputOrderPutOnItem(
			Long putOnItemId, Long itemId) throws Exception {
		PurchaseInputOrderPutOnItemDTO item = new PurchaseInputOrderPutOnItemDTO();
		item.setId(putOnItemId);
		item.setPurchaseInputOrderItemId(itemId); 
		item.setGoodsAllocationId(1L); 
		item.setPutOnShelvesCount(1000L); 
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		return item;
	}
	
	/**
	 * 创建退货入库单
	 * @return 退货入库单
	 * @throws Exception
	 */
	private ReturnGoodsInputOrderDTO createReturnGoodsInputOrder() throws Exception {
		ReturnGoodsInputOrderDTO returnGoodsInputOrder = new ReturnGoodsInputOrderDTO();
		
		returnGoodsInputOrder.setId(1L); 
		returnGoodsInputOrder.setUserAccountId(1L); 
		returnGoodsInputOrder.setOrderId(1L); 
		returnGoodsInputOrder.setOrderNo("test"); 
		returnGoodsInputOrder.setReturnGoodsInputOrderStatus(3); 
		returnGoodsInputOrder.setConsignee("张三");
		returnGoodsInputOrder.setDeliveryAddress("测试地址"); 
		returnGoodsInputOrder.setConsigneeCellPhoneNumber("18910106578");
		returnGoodsInputOrder.setFreight(45.90);
		returnGoodsInputOrder.setPayType(1); 
		returnGoodsInputOrder.setTotalAmount(999.00); 
		returnGoodsInputOrder.setDiscountAmount(50.40);
		returnGoodsInputOrder.setCouponAmount(35.00); 
		returnGoodsInputOrder.setPayableAmount(899.30); 
		returnGoodsInputOrder.setInvoiceTitle("测试发票抬头"); 
		returnGoodsInputOrder.setTaxpayerId("测试纳税人识别号");
		returnGoodsInputOrder.setOrderComment("测试订单");
		returnGoodsInputOrder.setReturnGoodsReason("测试退货原因");
		returnGoodsInputOrder.setReturnGoodsComment("测试退货备注"); 
		returnGoodsInputOrder.setArrivalTime(dateProvider.parseDatetime("2018-01-10 10:00:00")); 
		returnGoodsInputOrder.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		returnGoodsInputOrder.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		
		List<ReturnGoodsInputOrderItemDTO> items = new ArrayList<ReturnGoodsInputOrderItemDTO>();
		items.add(createReturnGoodsInputOrderItem(1L, 3L)); 
		items.add(createReturnGoodsInputOrderItem(1L, 4L)); 
		returnGoodsInputOrder.setReturnGoodsInputOrderItemDTOs(items); 
		
		List<ReturnGoodsInputOrderPutOnItemDTO> putOnItems = 
				new ArrayList<ReturnGoodsInputOrderPutOnItemDTO>();
		putOnItems.add(createReturnGoodsInputOrderPutOnItem(1L, 1L)); 
		putOnItems.add(createReturnGoodsInputOrderPutOnItem(2L, 2L));  
		returnGoodsInputOrder.setReturnGoodsInputOrderPutOnItemDTO(putOnItems); 
		
		return returnGoodsInputOrder;
	}
	
	/**
	 * 创建退货入库单条目
	 * @param returnGoodsInputOrderId 退货入库单id
	 * @return 退货入库单条目
	 * @throws Exception
	 */
	private ReturnGoodsInputOrderItemDTO createReturnGoodsInputOrderItem(
			Long returnGoodsInputOrderId, 
			Long goodsSkuId) throws Exception {
		ReturnGoodsInputOrderItemDTO item = new ReturnGoodsInputOrderItemDTO();
		
		item.setReturnGoodsInputOrderId(returnGoodsInputOrderId); 
		item.setGoodsSkuId(goodsSkuId); 
		item.setGoodsSkuCode("测试编号"); 
		item.setGoodsName("测试商品"); 
		item.setSaleProperties("测试销售属性"); 
		item.setGoodsGrossWeight(59.30);
		item.setPurchaseQuantity(3L); 
		item.setPurchasePrice(39.30); 
		item.setPromotionActivityId(1L); 
		item.setGoodsLength(49.00); 
		item.setGoodsWidth(29.50); 
		item.setGoodsHeight(68.90); 
		item.setQualifiedCount(3L); 
		item.setArrivalCount(3L); 
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		
		return item;
	}
	
	/**
	 * 创建退货入库单上架条目
	 * @return 采购入库单上架条目
	 * @throws Exception
	 */
	private ReturnGoodsInputOrderPutOnItemDTO createReturnGoodsInputOrderPutOnItem(
			Long putOnItemId, Long itemId) throws Exception {
		ReturnGoodsInputOrderPutOnItemDTO item = new ReturnGoodsInputOrderPutOnItemDTO();
		item.setId(putOnItemId);
		item.setReturnGoodsInputOrderItemId(itemId); 
		item.setGoodsAllocationId(1L); 
		item.setPutOnShelvesCount(1000L); 
		item.setGmtCreate(dateProvider.parseDatetime("2018-01-01 10:00:00"));  
		item.setGmtModified(dateProvider.parseDatetime("2018-01-10 10:00:00"));  
		return item;
	}
	
}
