package com.zhss.eshop.schedule.dao;

import java.util.List;

import com.zhss.eshop.order.domain.OrderItemDTO;
import com.zhss.eshop.schedule.domain.ScheduleOrderPickingItemDTO;

/**
 * 拣货条目管理DAO接口
 * @author zhonghuashishan
 *
 */
public interface ScheduleOrderPickingItemDAO {

	/**
	 * 批量插入拣货条目
	 * @param orderItem 订单条目 
	 * @param pickingItems 拣货条目
	 * @throws Exception
	 */
	void batchSave(OrderItemDTO orderItem, 
			List<ScheduleOrderPickingItemDTO> pickingItems) throws Exception;
	
}
