package com.zhss.eshop.schedule.dao;

import java.util.List;

import com.zhss.eshop.order.domain.OrderItemDTO;
import com.zhss.eshop.schedule.domain.ScheduleOrderSendOutDetailDTO;

/**
 * 发货明细管理DAO接口
 * @author zhonghuashishan
 *
 */
public interface ScheduleOrderSendOutDetailDAO {

	/**
	 * 批量新增发货明细
	 * @param orderItem 订单条目
	 * @param sendOutDetails 发货明细
	 * @throws Exception
	 */
	void batchSave(OrderItemDTO orderItem, 
			List<ScheduleOrderSendOutDetailDTO> sendOutDetails) throws Exception;
	
}
