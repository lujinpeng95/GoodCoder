package com.zhss.eshop.comment.constant;

/**
 * 是否为默认评论的常量类
 * @author zhonghuashishan
 *
 */
public class DefaultComment {

	public static final Integer YES = 1;
	public static final Integer NO = 0;
	
}
