package com.zhss.eshop.schedule.service.impl;

/**
 * 销售出库调度器接口
 * @author zhonghuashishan
 *
 */
public interface SaleDeliveryScheduler {

}
