package com.zhss.eshop.comment.constant;

/**
 * 是否晒图的常量类
 * @author zhonghuashishan
 *
 */
public class ShowPictures {

	public static final Integer YES = 1;
	public static final Integer NO = 0;
	
}
