package com.zhss.eshop.Inventory.async;

import java.util.concurrent.ArrayBlockingQueue;

import org.springframework.stereotype.Component;

/**
 * 商品库存更新队列实现类
 * @author zhonghuashishan
 *
 */
@Component
public class GoodsStockUpdateQueueImpl implements GoodsStockUpdateQueue {
	
	/**
	 * 商品库存更新队列
	 */
	private ArrayBlockingQueue<GoodsStockUpdateMessage> queue = 
			new ArrayBlockingQueue<GoodsStockUpdateMessage>(1000); 

	/**
	 * 将一个消息放入队列
	 * @param message 消息
	 * @throws Exception
	 */
	public void put(GoodsStockUpdateMessage message) throws Exception {
		queue.put(message); 
	}
	
	/**
	 * 从队列中取出一个消息
	 * @return
	 * @throws Exception
	 */
	public GoodsStockUpdateMessage get() throws Exception {	
		return queue.take();
	}
	
}
