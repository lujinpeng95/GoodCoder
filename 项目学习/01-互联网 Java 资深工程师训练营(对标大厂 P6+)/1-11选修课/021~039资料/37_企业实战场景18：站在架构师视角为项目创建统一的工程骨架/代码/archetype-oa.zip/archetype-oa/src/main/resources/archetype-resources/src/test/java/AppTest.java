package ${package};
 
import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigourous Test :-)
     */
	@Test
    public void testApp()
    {
        assertTrue( true );
    }
}
