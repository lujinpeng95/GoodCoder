package com.zhss.maven;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class HelloWorldTest {

	@Test
	public void testSayHello() {
		HelloWorld helloWorld = new HelloWorld();
		String result = helloWorld.sayHello("leo");
		assertEquals("hello, leo", result);  
	}
	
}
