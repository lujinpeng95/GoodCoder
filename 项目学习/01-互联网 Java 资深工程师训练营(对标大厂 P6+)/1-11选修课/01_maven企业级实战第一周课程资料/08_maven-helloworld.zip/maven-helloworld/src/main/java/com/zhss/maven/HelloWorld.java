package com.zhss.maven;

public class HelloWorld {

	public String sayHello(String name) {
		return "hello, " + name;
	}
	
	public static void main(String[] args) {
		System.out.println("hello world......");  
	}
	
}
