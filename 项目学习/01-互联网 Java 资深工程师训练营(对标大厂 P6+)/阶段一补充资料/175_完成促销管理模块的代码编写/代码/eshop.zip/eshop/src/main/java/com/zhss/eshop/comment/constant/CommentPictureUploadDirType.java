package com.zhss.eshop.comment.constant;

/**
 * 评论晒图上传目录类型的常量类
 * @author zhonghuashishan
 *
 */
public class CommentPictureUploadDirType {

	public static final String RELATIVE = "relative";
	public static final String ABSOLUTE = "absolute";
	
}
